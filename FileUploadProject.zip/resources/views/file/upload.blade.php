@extends('layouts.app')

@section('content')
    <div class="container">
    @if(session('success'))
            <div class="alert alert-success alert-dismissible"  role="alert">
            <strong>{{ session('success') }}</strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible" role="alert">
            <strong>{{ session('error') }}</strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                
            </div>
        @endif
        @foreach($files as $file)
            <div class="mb-3">
                <span>{{ $file->name }}</span>
                <div>
                    <a href="{{ route('file.download', $file->id) }}" class="btn btn-sm btn-success">Download</a>
                    <form action="{{ route('file.delete', $file->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this file?')">Delete</button>
                    </form>
                </div>
            </div>
        @endforeach

        <div class="card">
            <div class="card-header">Uploading Files</div>
            <div class="card-body">
                <form action="{{ route('file.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="files">Select File(s)</label>
                        <input id="files" type="file" name="files[]" multiple class="form-control-file">
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
            </div>
        </div>
    </div>
@endsection
