<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\File;

class FileUploadController extends Controller
{
    public function index()
    {
        $files = File::all();
        return view('file.upload', compact('files'));
    }

    public function store(Request $request)
    {
        if ($request->hasFile('files')) {
            foreach ($request->file('files') as $file) {
                $fileName = $file->getClientOriginalName();
                $filePath = $file->storeAs('uploads', $fileName);
                File::create(['name' => $fileName, 'path' => $filePath]);
            }
        }
        return redirect()->route('file.upload')->with('success', 'Files uploaded successfully.');
    }

    public function download($id)
    {
        $file = File::find($id);
        return Storage::download($file->path, $file->name);
    }

    public function destroy($id)
    {
        $file = File::find($id);
        Storage::delete($file->path);
        $file->delete();
        return redirect()->route('file.upload')->with('error', 'File deleted successfully.');
    }
}

