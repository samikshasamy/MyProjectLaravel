<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FileUploadController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/upload', [FileUploadController::class, 'index'])->name('file.upload');
Route::post('/upload/store', [FileUploadController::class, 'store'])->name('file.store');
Route::get('/file/{id}/download', [FileUploadController::class, 'download'])->name('file.download');
Route::delete('/file/{id}/delete', [FileUploadController::class, 'destroy'])->name('file.delete');

